<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFacilityInfoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('facility_info', function (Blueprint $table) {
            // Primary Key
            $table->id(); // Auto-incrementing ID

            // Foreign Key to bonds table
            $table->foreignId('bond_id') // Foreign key referencing bonds
                ->constrained('bonds') // Ensure it references the correct table
                ->onDelete('cascade'); // Cascade delete for related facility info

            // Facility Information
            $table->string('facility_code', 50)->unique(); // Unique facility code
            $table->string('facility_number', 50)->nullable(); // Facility number
            $table->string('facility_name', 255)->nullable(); // New field for facility name
            $table->enum('principle_type', ['Conventional', 'Islamic'])->nullable(); // Principle type
            $table->string('islamic_concept', 100)->nullable(); // Islamic concept (if applicable)
            $table->date('maturity_date')->nullable(); // Maturity date
            $table->string('instrument', 50)->nullable(); // Instrument type (e.g., "MTN")
            $table->string('instrument_type', 50)->nullable(); // Instrument category (e.g., "Medium Term Notes")
            $table->boolean('guaranteed')->default(false); // Whether the facility is guaranteed
            $table->decimal('total_guaranteed', 18, 4)->default(0.0000); // Total guaranteed amount (RM)
            $table->enum('indicator', ['Rated', 'Unrated'])->nullable(); // Rating indicator
            $table->string('facility_rating', 50)->nullable(); // Facility rating (e.g., "A3 (RAM)")

            // Financial Information
            $table->decimal('facility_amount', 18, 2)->nullable(); // Facility amount (RM)
            $table->decimal('available_limit', 18, 2)->nullable(); // Available limit (RM)
            $table->decimal('outstanding_amount', 18, 2)->default(0.00); // Outstanding amount (RM)

            // Agents
            $table->string('trustee_security_agent', 255)->nullable(); // Trustee/security agent
            $table->string('lead_arranger', 255)->nullable(); // Lead arranger (e.g., "AFFNINV")
            $table->string('facility_agent', 255)->nullable(); // Facility agent (e.g., "AFFNINV")

            // Availability
            $table->date('availability_date')->nullable(); // Availability date

            // Timestamps
            $table->timestamps(); // Created at and Updated at timestamps
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('facility_info');
    }
}