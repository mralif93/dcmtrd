<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAnnouncementsTable extends Migration
{
    public function up()
    {
        Schema::create('announcements', function (Blueprint $table) {
            $table->id(); // Primary Key
            $table->date('announcement_date'); // Announcement Date
            $table->string('category', 255); // Category
            $table->string('sub_category', 255); // Sub-Category
            $table->string('title', 255); // Title
            $table->foreignId('issuer_id')->constrained('issuers')->onDelete('cascade'); // Foreign Key referencing issuers table
            $table->text('description')->nullable(); // Description
            $table->text('content'); // Content
            $table->string('attachment')->nullable(); // Attachment (optional)
            $table->string('source', 255)->nullable(); // Source (optional)
            $table->timestamps(); // Created at and Updated at timestamps
        });
    }

    public function down()
    {
        Schema::dropIfExists('announcements');
    }
}
