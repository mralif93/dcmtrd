<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBondsInfoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('bonds_info', function (Blueprint $table) {
            // Primary Key
            $table->id(); // Auto-incrementing ID

            // Foreign Key to bonds table
            $table->foreignId('bond_id') // Foreign key referencing bonds
                ->constrained('bonds') // Ensure it references the correct table
                ->onDelete('cascade'); // Cascade delete for related bond info

            // General Information
            $table->string('issuer_name', 255); // Name of the issuer
            $table->string('principal', 50); // Principal type (e.g., Corporate)
            $table->string('isin_code', 50)->unique(); // ISIN Code (unique identifier for the bond)
            $table->string('stock_code', 50); // Stock code for trading
            $table->string('instrument_code', 50); // Instrument code (e.g., MTN)
            $table->string('category', 50); // Category (e.g., Corporate)
            $table->string('sub_category', 100)->nullable(); // Sub-category (optional, e.g., Non SRI and ASEAN Bond)
            $table->date('issue_date'); // Issue date of the bond
            $table->date('maturity_date'); // Maturity date of the bond

            // Coupon Information
            $table->decimal('coupon_rate', 5, 4)->nullable(); // Coupon rate (e.g., 5.7000)
            $table->string('coupon_type', 50)->nullable(); // Coupon type (e.g., Fixed Rate)
            $table->string('coupon_frequency', 50)->nullable(); // Coupon payment frequency (e.g., Semi-annually)
            $table->string('day_count', 50)->nullable(); // Day count convention (e.g., ACTUAL/365)

            // Tenure Information
            $table->decimal('issue_tenure_years', 10, 4)->nullable(); // Issue tenure in years (e.g., 95.0630)
            $table->decimal('residual_tenure_years', 10, 4)->nullable(); // Residual tenure in years (e.g., 93.4630)

            // Latest Trading Information
            $table->decimal('last_traded_yield', 5, 2)->nullable(); // Last traded yield (e.g., 4.18)
            $table->decimal('last_traded_price', 10, 2)->nullable(); // Last traded price in RM (e.g., 104.80)
            $table->decimal('last_traded_amount', 10, 2)->nullable(); // Last traded amount in RM (e.g., 0.25)
            $table->date('last_traded_date')->nullable(); // Date of the last trade

            // Ratings
            $table->string('ratings', 50)->nullable(); // Bond ratings (e.g., A3 (RAM))

            // Coupon Payment Details
            $table->date('coupon_accrual')->nullable(); // Start of the coupon accrual period
            $table->date('prev_coupon_payment_date')->nullable(); // Previous coupon payment date
            $table->date('first_coupon_payment_date')->nullable(); // First coupon payment date
            $table->date('next_coupon_payment_date')->nullable(); // Next coupon payment date
            $table->date('last_coupon_payment_date')->nullable(); // Last coupon payment date

            // Issuance Details
            $table->decimal('amount_issued', 15, 2); // Amount issued in RM (e.g., 500 million)
            $table->decimal('amount_outstanding', 15, 2); // Amount outstanding in RM (e.g., 500 million)

            // Additional Information
            $table->string('lead_arranger', 255)->nullable(); // Lead arranger (e.g., AFFNINV)
            $table->string('facility_agent', 255)->nullable(); // Facility agent (e.g., AFFNINV)
            $table->string('facility_code', 50)->nullable(); // Link to facility_info table

            // Status and Approval Information
            $table->enum('status', ['pending review', 'approved'])->default('pending review'); // Status of the bond info
            $table->timestamp('approval_date_time')->nullable(); // Approval date and time

            // Timestamps
            $table->timestamps(); // Created at and Updated at timestamps
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('bonds_info');
    }
}