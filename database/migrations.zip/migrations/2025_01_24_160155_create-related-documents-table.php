<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRelatedDocumentsTable extends Migration
{
    public function up()
    {
        Schema::create('related_documents', function (Blueprint $table) {
            $table->id(); // Primary Key
            $table->string('document_name', 255)->nullable(); // Document name
            $table->string('document_type', 255)->nullable(); // Document type
            $table->date('upload_date')->nullable(); // Upload date
            $table->string('file_path')->nullable(); // Column to store the uploaded document's file path
            $table->foreignId('facility_id') // Foreign key referencing facility_info
                ->nullable()
                ->constrained('facility_info') // Assuming you have a facility_info table
                ->onDelete('cascade'); // Cascade delete for related documents
            $table->timestamps(); // Created at and Updated at timestamps
        });
    }

    public function down()
    {
        Schema::dropIfExists('related_documents');
    }
}