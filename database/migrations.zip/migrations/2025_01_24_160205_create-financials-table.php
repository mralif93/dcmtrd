<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFinancialsTable extends Migration
{
    public function up()
    {
        Schema::create('financials', function (Blueprint $table) {
            $table->id(); // Primary Key
            $table->foreignId('bond_id')->constrained('bonds'); // Foreign Key
            $table->integer('financial_year');
            $table->decimal('revenue', 15, 2);
            $table->decimal('expenses', 15, 2);
            $table->decimal('net_income', 15, 2);
            $table->timestamps(); // Created at and Updated at timestamps
        });
    }

    public function down()
    {
        Schema::dropIfExists('financials');
    }
}
