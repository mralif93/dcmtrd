<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBondsTable extends Migration
{
    public function up()
    {
        Schema::create('bonds', function (Blueprint $table) {
            // Primary Key
            $table->id(); // Auto-incrementing ID

            // Bond/Sukuk Information
            $table->string('bond_sukuk_name', 255); // Bond/Sukuk Name
            $table->string('sub_name', 100)->nullable(); // Sub-Name
            $table->string('rating', 50); // Rating
            $table->string('category', 100); // Category
            $table->date('last_traded_date')->nullable(); // Last Traded Date
            $table->decimal('last_traded_yield', 5, 2); // Last Traded Yield (%)
            $table->decimal('last_traded_price', 10, 2); // Last Traded Price (RM)
            $table->decimal('last_traded_amount', 10, 2); // Last Traded Amount (RM 'mil)
            $table->decimal('o_s_amount', 10, 2); // O/S Amount (RM 'mil)
            $table->decimal('residual_tenure', 5, 2); // Residual Tenure (Years)

            // Foreign Key referencing issuers table
            $table->foreignId('issuer_id')->constrained('issuers')->onDelete('cascade'); 

            // Timestamps
            $table->timestamps(); // Created at and Updated at timestamps
        });
    }

    public function down()
    {
        Schema::dropIfExists('bonds');
    }
}