<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateIssuersTable extends Migration
{
    public function up()
    {
        Schema::create('issuer', function (Blueprint $table) {
            $table->id(); // Primary Key
            $table->string('issuer_short_name', 255);
            $table->string('issuer_name', 255);
            $table->string('registration_number', 255);
            $table->decimal('debenture', 15, 2)->nullable(); // Debenture amount
            $table->decimal('trustee_fee_amount_1', 15, 2)->nullable(); // Trustee fee amount 1
            $table->decimal('trustee_fee_amount_2', 15, 2)->nullable(); // Trustee fee amount 2
            $table->dateTime('reminder_1')->nullable(); // Reminder 1
            $table->dateTime('reminder_2')->nullable(); // Reminder 2
            $table->dateTime('reminder_3')->nullable(); // Reminder 3
            $table->string('trustee_role_1', 255)->nullable(); // Trustee role 1
            $table->string('trustee_role_2', 255)->nullable(); // Trustee role 2
            $table->date('trust_deed_date')->nullable(); // Trust deed date
            $table->timestamps(); // Created at and Updated at timestamps
        });
    }

    public function down()
    {
        Schema::dropIfExists('issuers');
    }
}