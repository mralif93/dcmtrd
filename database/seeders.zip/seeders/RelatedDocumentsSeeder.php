<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class RelatedDocumentsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Sample data for related documents
        $documents = [
            [
                'document_name' => 'Affin Bank AT1CS - OTC (LOLA OSS)(clean).pdf',
                'document_type' => 'Principal Terms and Conditions',
                'upload_date' => now(), // You can set a specific date if needed
                'facility_id' => 1, // Adjust this based on your facility_info table
            ],
            [
                'document_name' => 'Trust Deed dated 5 July 2018.pdf',
                'document_type' => 'Trust Deed',
                'upload_date' => now(),
                'facility_id' => 1, // Adjust this based on your facility_info table
            ],
            [
                'document_name' => 'AFFIN - Information Memorandum dated 2 July 2018 (FINAL).pdf',
                'document_type' => 'Information Memorandum',
                'upload_date' => now(),
                'facility_id' => 1, // Adjust this based on your facility_info table
            ],
        ];

        // Insert the documents into the related_documents table
        DB::table('related_documents')->insert($documents);
    }
}