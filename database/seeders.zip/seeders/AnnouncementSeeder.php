<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Announcement;
use App\Models\Issuer;

class AnnouncementSeeder extends Seeder
{
    public function run()
    {
        // Assuming you have at least one issuer in the issuers table
        $issuer = Issuer::first(); // Get the first issuer

        if ($issuer) {
            // Create the first announcement
            Announcement::create([
                'announcement_date' => '2023-07-04',
                'category' => 'NEWS FROM MEMBERS',
                'sub_category' => 'NEWS FROM MEMBERS',
                'title' => 'AFFIN BANK BERHAD (AT1CS PROGRAMME OF UP TO RM3.0 BILLION)',
                'issuer_id' => $issuer->id, // Reference the issuer ID
                'description' => null, // Assuming no description provided
                'content' => "We, the Facility Agent, wish to inform that the Issuer, Affin Bank Berhad, had today issued Notice of Exercise of Call Option on its intention to early redeem Stock UZ180095 in full on 31.7.2023 (''Call Notice'').\n\nThe letter enclosing the Call Notice has been distributed to the noteholders by the Trustee via email today, 3.7.2023.\n\n*** DISCLAIMER ***\nTHIS COMPUTER SYSTEMS AND APPLICATIONS ARE OWNED AND OPERATED BY BURSA MALAYSIA.",
                'attachment' => null, // Assuming no attachment provided
                'source' => 'BURSA',
            ]);

            // Create the second announcement
            Announcement::create([
                'announcement_date' => '2023-08-15',
                'category' => 'FINANCIAL REPORT',
                'sub_category' => 'QUARTERLY RESULTS',
                'title' => 'Q2 2023 Financial Results Announcement',
                'issuer_id' => $issuer->id, // Reference the issuer ID
                'description' => 'Announcement of the financial results for Q2 2023.',
                'content' => "We are pleased to announce our financial results for the second quarter of 2023. The results show a significant increase in revenue compared to the previous quarter.",
                'attachment' => 'q2_2023_results.pdf', // Example attachment
                'source' => 'COMPANY WEBSITE',
            ]);

            // Create the third announcement
            Announcement::create([
                'announcement_date' => '2023-09-01',
                'category' => 'MARKET UPDATE',
                'sub_category' => 'ECONOMIC INDICATORS',
                'title' => 'Monthly Economic Indicators Update',
                'issuer_id' => $issuer->id,
                'description' => 'Update on the latest economic indicators for August 2023.',
                'content' => "The latest economic indicators for August 2023 show a positive trend in consumer spending and investment.",
                'attachment' => null,
                'source' => 'ECONOMIC REPORT',
            ]);

            // Create the fourth announcement
            Announcement::create([
                'announcement_date' => '2023-09-15',
                'category' => 'CORPORATE ACTION',
                'sub_category' => 'DIVIDEND ANNOUNCEMENT',
                'title' => 'Dividend Declaration for Q3 2023',
                'issuer_id' => $issuer->id,
                'description' => 'Announcement of the dividend for the third quarter of 2023.',
                'content' => "The Board of Directors has declared a dividend of RM0.10 per share for Q3 2023, payable on 15 October 2023.",
                'attachment' => null,
                'source' => 'COMPANY ANNOUNCEMENT',
            ]);

            // Create the fifth announcement
            Announcement::create([
                'announcement_date' => '2023-10-01',
                'category' => 'EVENT',
                'sub_category' => 'ANNUAL GENERAL MEETING',
                'title' => 'Notice of Annual General Meeting 2023',
                'issuer_id' => $issuer->id,
                'description' => 'Notice for the upcoming Annual General Meeting.',
                'content' => "We hereby notify our shareholders that the Annual General Meeting will be held on 30 October 2023 at 10:00 AM.",
                'attachment' => 'agm_notice.pdf',
                'source' => 'COMPANY WEBSITE',
            ]);
        } else {
            // Handle the case where there are no issuers
            $this->command->info('No issuers found. Please create an issuer first.');
        }
    }
}