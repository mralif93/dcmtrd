<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\Bond;

class BondsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        $bondsData = [
            [
                'bond_sukuk_name' => 'MYR 500 Million 5-Year Bond',
                'sub_name' => '5-Year Bond Issue 2023',
                'rating' => 'AAA (RAM)',
                'category' => 'Corporate',
                'last_traded_date' => '2023-09-01',
                'last_traded_yield' => 3.50,
                'last_traded_price' => 101.00,
                'last_traded_amount' => 0.50,
                'o_s_amount' => 500000000, // Outstanding amount in RM
                'residual_tenure' => 4.00, // Residual tenure in years
                'issuer_id' => 1, // Assuming this issuer_id exists in the issuers table
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'bond_sukuk_name' => 'MYR 300 Million 10-Year Sukuk',
                'sub_name' => '10-Year Sukuk Issue 2023',
                'rating' => 'AA (Fitch)',
                'category' => 'Sukuk',
                'last_traded_date' => '2023-09-15',
                'last_traded_yield' => 4.00,
                'last_traded_price' => 99.50,
                'last_traded_amount' => 0.30,
                'o_s_amount' => 300000000, // Outstanding amount in RM
                'residual_tenure' => 9.00, // Residual tenure in years
                'issuer_id' => 2, // Assuming this issuer_id exists in the issuers table
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'bond_sukuk_name' => 'MYR 200 Million 7-Year Green Bond',
                'sub_name' => 'Green Bond Issue 2023',
                'rating' => 'A (S&P)',
                'category' => 'Green',
                'last_traded_date' => '2023-09-10',
                'last_traded_yield' => 4.25,
                'last_traded_price' => 100.75,
                'last_traded_amount' => 0.40,
                'o_s_amount' => 200000000, // Outstanding amount in RM
                'residual_tenure' => 6.00, // Residual tenure in years
                'issuer_id' => 3, // Assuming this issuer_id exists in the issuers table
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'bond_sukuk_name' => 'MYR 400 Million 15-Year Bond',
                'sub_name' => '15-Year Bond Issue 2023',
                'rating' => 'AA- (Moody\'s)',
                'category' => 'Corporate',
                'last_traded_date' => '2023-09-20',
                'last_traded_yield' => 4.10,
                'last_traded_price' => 98.50,
                'last_traded_amount' => 0.35,
                'o_s_amount' => 400000000, // Outstanding amount in RM
                'residual_tenure' => 14.00, // Residual tenure in years
                'issuer_id' => 4, // Assuming this issuer_id exists in the issuers table
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'bond_sukuk_name' => 'MYR 250 Million 12-Year Sukuk',
                'sub_name' => '12-Year Sukuk Issue 2023',
                'rating' => 'A+ (Fitch)',
                'category' => 'Sukuk',
                'last_traded_date' => '2023-09-25',
                'last_traded_yield' => 4.30,
                'last_traded_price' => 101.25,
                'last_traded_amount' => 0.45,
                'o_s_amount' => 250000000, // Outstanding amount in RM
                'residual_tenure' => 11.00, // Residual tenure in years
                'issuer_id' => 5, // Assuming this issuer_id exists in the issuers table
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ];

        // Insert data into the bonds table
        DB::table('bonds')->insert($bondsData);
    }
}
