<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class BondsInfoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Sample data for bonds_info
        $bondsInfoData = [
            [
                'bond_id' => 1,
                'issuer_name' => 'Issuer A',
                'principal' => 'Corporate',
                'isin_code' => 'US1234567890',
                'stock_code' => 'BOND1',
                'instrument_code' => 'MTN',
                'category' => 'Corporate',
                'sub_category' => 'Non SRI',
                'issue_date' => '2023-01-01',
                'maturity_date' => '2033-01-01',
                'coupon_rate' => 5.70,
                'coupon_type' => 'Fixed Rate',
                'coupon_frequency' => 'Semi-annually',
                'day_count' => 'ACTUAL/365',
                'issue_tenure_years' => 10.00,
                'residual_tenure_years' => 9.00,
                'last_traded_yield' => 4.50,
                'last_traded_price' => 102.50,
                'last_traded_amount' => 0.25,
                'last_traded_date' => '2023-09-01',
                'ratings' => 'A3 (RAM)',
                'amount_issued' => 500000000,
                'amount_outstanding' => 500000000,
                'lead_arranger' => 'Lead Arranger A',
                'facility_agent' => 'Facility Agent A',
                'facility_code' => 'FACILITY1',
                'status' => 'pending review', // New field for status
                'approval_date_time' => null, // New field for approval date/time
                'created_at' => now(),
                'updated_at' => now(),
            ],
            // Additional bond entries...
            [
                'bond_id' => 2,
                'issuer_name' => 'Issuer B',
                'principal' => 'Sovereign',
                'isin_code' => 'US0987654321',
                'stock_code' => 'BOND2',
                'instrument_code' => 'GOV',
                'category' => 'Government',
                'sub_category' => 'SRI',
                'issue_date' => '2023-02-01',
                'maturity_date' => '2033-02-01',
                'coupon_rate' => 4.50,
                'coupon_type' => 'Floating Rate',
                'coupon_frequency' => 'Quarterly',
                'day_count' => 'ACTUAL/360',
                'issue_tenure_years' => 10.00,
                'residual_tenure_years' => 9.00,
                'last_traded_yield' => 3.80,
                'last_traded_price' => 101.00,
                'last_traded_amount' => 0.50,
                'last_traded_date' => '2023-09-15',
                'ratings' => 'AA (F itch)',
                'amount_issued' => 300000000,
                'amount_outstanding' => 300000000,
                'lead_arranger' => 'Lead Arranger B',
                'facility_agent' => 'Facility Agent B',
                'facility_code' => 'FACILITY2',
                'status' => 'approved', // New field for status
                'approval_date_time' => now(), // New field for approval date/time
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'bond_id' => 3,
                'issuer_name' => 'Issuer C',
                'principal' => 'Corporate',
                'isin_code' => 'US1122334455',
                'stock_code' => 'BOND3',
                'instrument_code' => 'MTN',
                'category' => 'Corporate',
                'sub_category' => 'Non SRI',
                'issue_date' => '2023-03-01',
                'maturity_date' => '2033-03-01',
                'coupon_rate' => 5.25,
                'coupon_type' => 'Fixed Rate',
                'coupon_frequency' => 'Semi-annually',
                'day_count' => 'ACTUAL/365',
                'issue_tenure_years' => 10.00,
                'residual_tenure_years' => 9.00,
                'last_traded_yield' => 4.20,
                'last_traded_price' => 103.00,
                'last_traded_amount' => 0.30,
                'last_traded_date' => '2023-09-10',
                'ratings' => 'A (S&P)',
                'amount_issued' => 400000000,
                'amount_outstanding' => 400000000,
                'lead_arranger' => 'Lead Arranger C',
                'facility_agent' => 'Facility Agent C',
                'facility_code' => 'FACILITY3',
                'status' => 'pending review', // New field for status
                'approval_date_time' => null, // New field for approval date/time
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'bond_id' => 4,
                'issuer_name' => 'Issuer D',
                'principal' => 'Sovereign',
                'isin_code' => 'US2233445566',
                'stock_code' => 'BOND4',
                'instrument_code' => 'GOV',
                'category' => 'Government',
                'sub_category' => 'SRI',
                'issue_date' => '2023-04-01',
                'maturity_date' => '2033-04-01',
                'coupon_rate' => 4.75,
                'coupon_type' => 'Fixed Rate',
                'coupon_frequency' => 'Semi-annually',
                'day_count' => 'ACTUAL/365',
                'issue_tenure_years' => 10.00,
                'residual_tenure_years' => 9.00,
                'last_traded_yield' => 3.90,
                'last_traded_price' => 100.50,
                'last_traded_amount' => 0.40,
                'last_traded_date' => '2023-09-20',
                'ratings' => 'AA- (Moody\'s)',
                'amount_issued' => 600000000,
                'amount_outstanding' => 600000000,
                'lead_arranger' => 'Lead Arranger D',
                'facility_agent' => 'Facility Agent D',
                'facility_code' => 'FACILITY4',
                'status' => 'approved', // New field for status
                'approval_date_time' => now(), // New field for approval date/time
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'bond_id' => 5,
                'issuer_name' => 'Issuer E',
                'principal' => 'Corporate',
                'isin_code' => 'US3344556677',
                'stock_code' => 'BOND5',
                'instrument_code' => 'MTN',
                'category' => 'Corporate',
                'sub_category' => 'Non SRI',
                'issue_date' => '2023-05-01',
                'maturity_date' => '2033-05-01',
                'coupon_rate' => 5.00,
                'coupon_type' => 'Fixed Rate',
                'coupon_frequency' => 'Semi-annually',
                'day_count' => 'ACTUAL/365',
                'issue_tenure_years' => 10.00,
                'residual_tenure_years' => 9.00,
                'last_traded_yield' => 4.10,
                'last_traded_price' => 101.50,
                'last_traded_amount' => 0.35,
                'last_traded_date' => '2023-09-25',
                'ratings' => 'A+ (Fitch)',
                'amount_issued' => 450000000,
                'amount_outstanding' => 450000000,
                'lead_arranger' => 'Lead Arranger E',
                'facility_agent' => 'Facility Agent E',
                'facility_code' => 'FACILITY5',
                'status' => 'pending review', // New field for status
                'approval_date_time' => null, // New field for approval date/time
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ];

        // Insert data into the bonds_info table
        DB::table('bonds_info')->insert($bondsInfoData);
    }
}