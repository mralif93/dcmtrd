<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class IssuersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
    {
        // Sample data for issuers
        $issuersData = [
            [
                'issuer_short_name' => 'Gov Malaysia',
                'issuer_name' => 'Government of Malaysia',
                'registration_number' => '123456-V',
                'debenture' => 1000000000.00, // Example debenture amount
                'trustee_fee_amount_1' => 50000.00, // Example trustee fee amount 1
                'trustee_fee_amount_2' => 30000.00, // Example trustee fee amount 2
                'reminder_1' => now()->addDays(30), // Example reminder 1 (30 days from now)
                'reminder_2' => now()->addDays(60), // Example reminder 2 (60 days from now)
                'reminder_3' => now()->addDays(90), // Example reminder 3 (90 days from now)
                'trustee_role_1' => 'Trustee Role A', // Example trustee role 1
                'trustee_role_2' => 'Trustee Role B', // Example trustee role 2
                'trust_deed_date' => now()->subYears(1), // Example trust deed date (1 year ago)
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'issuer_short_name' => 'PETRONAS',
                'issuer_name' => 'Petroliam Nasional Berhad',
                'registration_number' => '123456-A',
                'debenture' => 2000000000.00, // Example debenture amount
                'trustee_fee_amount_1' => 70000.00, // Example trustee fee amount 1
                'trustee_fee_amount_2' => 40000.00, // Example trustee fee amount 2
                'reminder_1' => now()->addDays(30),
                'reminder_2' => now()->addDays(60),
                'reminder_3' => now()->addDays(90),
                'trustee_role_1' => 'Trustee Role C',
                'trustee_role_2' => 'Trustee Role D',
                'trust_deed_date' => now()->subYears(1),
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'issuer_short_name' => 'TNB',
                'issuer_name' => 'Tenaga Nasional Berhad',
                'registration_number' => '654321-B',
                'debenture' => 1500000000.00,
                'trustee_fee_amount_1' => 60000.00,
                'trustee_fee_amount_2' => 35000.00,
                'reminder_1' => now()->addDays(30),
                'reminder_2' => now()->addDays(60),
                'reminder_3' => now()->addDays(90),
                'trustee_role_1' => 'Trustee Role E',
                'trustee_role_2' => 'Trustee Role F',
                'trust_deed_date' => now()->subYears(1),
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'issuer_short_name' => 'MBB',
                'issuer_name' => 'Malayan Banking Berhad',
                'registration_number' => '789012-C',
                'debenture' => 1200000000.00,
                'trustee_fee_amount_1' => 55000.00,
                'trustee_fee_amount_2' => 32000.00,
                'reminder_1' => now()->addDays(30),
                'reminder_2' => now()->addDays(60),
                'reminder_3' => now()->addDays(90),
                'trustee_role_1' => 'Trustee Role G',
                'trustee_role_2' => 'Trustee Role H',
                'trust_deed_date' => now()->subYears(1),
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'issuer_short_name' => 'CIMB',
                'issuer_name' => 'CIMB Group Holdings Berhad',
                'registration_number' => '345678-D',
                'debenture' => 1800000000.00,
                'trustee_fee_amount_1' => 80000.00,
                'trustee_fee_amount_2' => 45000.00,
                'reminder_1' => now()->addDays(30),
                'reminder_2' => now()->addDays(60),
                'reminder_3' => now()->addDays(90),
                'trustee_role_1' => 'Trustee Role I',
                'trustee_role_2' => 'Trustee Role J',
                'trust_deed_date' => now()->subYears(1),
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ];

        // Insert data into the issuers table
        DB::table('issuers')->insert($issuersData);
    }
}