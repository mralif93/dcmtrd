<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class FacilityInfoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Sample data for facility_info
        $facilityInfoData = [
            [
                'bond_id' => 1, // Assuming this bond_id exists in the bonds table
                'facility_code' => 'FACILITY1',
                'facility_number' => 'F001',
                'facility_name' => 'Main Term Loan Facility', // New field for facility name
                'principle_type' => 'Conventional',
                'islamic_concept' => null,
                'maturity_date' => '2033-01-01',
                'instrument' => 'Term Loan',
                'instrument_type' => 'Medium Term Notes',
                'guaranteed' => true,
                'total_guaranteed' => 500000000, // 500 million
                'indicator' => 'Rated',
                'facility_rating' => 'A (S&P)',
                'facility_amount' => 500000000, // 500 million
                'available_limit' => 300000000, // 300 million
                'outstanding_amount' => 200000000, // 200 million
                'trustee_security_agent' => 'Trustee A',
                'lead_arranger' => 'Lead Arranger A',
                'facility_agent' => 'Facility Agent A',
                'availability_date' => '2023-01-01',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'bond_id' => 2,
                'facility_code' => 'FACILITY2',
                'facility_number' => 'F002',
                'facility_name' => 'Islamic Sukuk Facility', // New field for facility name
                'principle_type' => 'Islamic',
                'islamic_concept' => 'Murabaha',
                'maturity_date' => '2033-02-01',
                'instrument' => 'Sukuk',
                'instrument_type' => 'Islamic Bonds',
                'guaranteed' => false,
                'total_guaranteed' => 0,
                'indicator' => 'Unrated',
                'facility_rating' => null,
                'facility_amount' => 300000000, // 300 million
                'available_limit' => 200000000, // 200 million
                'outstanding_amount' => 100000000, // 100 million
                'trustee_security_agent' => 'Trustee B',
                'lead_arranger' => 'Lead Arranger B',
                'facility_agent' => 'Facility Agent B',
                'availability_date' => '2023-02-01',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'bond_id' => 3,
                'facility_code' => 'FACILITY3',
                'facility_number' => 'F003',
                'facility_name' => 'Conventional Term Loan Facility', // New field for facility name
                'principle_type' => 'Conventional',
                'islamic_concept' => null,
                'maturity_date' => '2033-03-01',
                'instrument' => 'Term Loan',
                'instrument_type' => 'Medium Term Notes',
                'guaranteed' => true,
                'total_guaranteed' => 400000000, // 400 million
                'indicator' => 'Rated',
                'facility_rating' => 'AA (Fitch)',
                'facility_amount' => 400000000, // 400 million
                'available_limit' => 250000000, // 250 million
                'outstanding_amount' => 150000000, // 150 million
                'trustee_security_agent' => 'Trustee C',
                'lead_arranger' => 'Lead Arranger C',
                'facility_agent' => 'Facility Agent C',
                'availability_date' => '2023-03-01',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'bond_id' => 4,
                'facility_code' => 'FACILITY4',
                'facility_number' => 'F004',
                'facility_name' => 'Islamic Ijarah Facility', // New field for facility name
                'principle_type' => 'Islamic',
                'islamic_concept' => 'Ijarah',
                'maturity_date' => '2033-04-01',
                'instrument' => 'Sukuk',
                'instrument_type' => 'Islamic Bonds',
                'guaranteed' => false,
                'total_guaranteed' => 0,
                'indicator' => 'Unrated',
                'facility_rating' => null,
                'facility_amount' => 600000000, // 600 million
                'available_limit' => 400000000, // 400 million
                'outstanding_amount' => 200000000, // 200 million
                'trustee_security_agent' => 'Trustee D',
                'lead_arranger' => 'Lead Arranger D',
                'facility_agent' => 'Facility Agent D',
                'availability_date' => '2023-04-01',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'bond_id' => 5,
                'facility_code' => 'FACILITY5',
                'facility_number' => 'F005',
                'facility_name' => 'Conventional Term Loan Facility 2', // New field for facility name
                'principle_type' => 'Conventional',
                'islamic_concept' => null,
                'maturity_date' => '2033-05-01',
                'instrument' => 'Term Loan',
                'instrument_type' => 'Medium Term Notes',
                'guaranteed' => true,
                'total_guaranteed' => 450000000, // 450 million
                'indicator' => 'Rated',
                'facility_rating' => 'A+ (Fitch)',
                'facility_amount' => 450000000, // 450 million
                'available_limit' => 300000000, // 300 million
                'outstanding_amount' => 150000000, // 150 million
                'trustee_security_agent' => 'Trustee E',
                'lead_arranger' => 'Lead Arranger E',
                'facility_agent' => 'Facility Agent E',
                'availability_date' => '2023-05-01',
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ];

        // Insert data into the facility_info table
        DB::table('facility_info')->insert($facilityInfoData);
    }
}